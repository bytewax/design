const { task, series, parallel, src, dest, watch } = require("gulp");

var gulp = require('gulp');
var sass = require('gulp-sass');
var postcss = require('gulp-postcss');
var autoprefixer = require('autoprefixer');
var cssnano = require('cssnano');
var concat = require('gulp-concat');
var rename = require('gulp-rename');
var babel = require('gulp-babel');

// Styles task
gulp.task('styles', function() {
    var plugins = [
        autoprefixer(),
        cssnano()
    ];
    return gulp.src('assets/src/scss/*.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(postcss(plugins))
    .pipe(gulp.dest('assets/dist/css/'))
});

// Javascript concat & minify task
gulp.task('js', function () {
    return gulp.src([
        'assets/src/js/plugins/*.js',
        'assets/src/js/*.js'
    ])
    .pipe(concat('dashboard.js'))
    .pipe(gulp.dest('assets/dist/js'))
    .pipe(rename('dashboard.min.js'))
    .pipe(babel({presets: ['minify']}))
    .pipe(gulp.dest('assets/dist/js'))
});

// Watch task
gulp.task('default',function() {
    return gulp.watch('assets/src/scss/**/*.scss',gulp.series('styles'));
});