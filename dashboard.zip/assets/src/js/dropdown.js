$(document).ready(function() {

    // Dropdown toggle
    $('.dropdown-toggle').click(function(e){
        e.stopPropagation();

        // Find menu based on element parent
        var dropdown = $(this).parent().find('.dropdown-menu');

        // Toggle active class to button
        $(this).toggleClass('dropdown-toggle--open');

        // Close / open dropdown menu
        if($(this).hasClass('dropdown-toggle--open')){
            $(dropdown).fadeIn();
        } else {
            $(dropdown).fadeOut();
        }
    });
    
    
    // Hide already opened dropdown menus
    $(window).click(function() {
        if($('.dropdown-toggle').hasClass('dropdown-toggle--open')){
            $('.dropdown-menu').fadeOut();
            $('.dropdown-toggle').toggleClass('dropdown-toggle--open');
        }
    });

});