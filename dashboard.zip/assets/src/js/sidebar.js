/** Sidebar toggler */
$('.sidebar__toggler').click(function(e){
    (e).preventDefault();
    $(this).toggleClass('sidebar__toggler--open');
    $(this).parent().find('.sidebar__nav').slideToggle();
});